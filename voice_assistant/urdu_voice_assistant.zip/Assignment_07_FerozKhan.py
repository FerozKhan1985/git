import streamlit as st
import speech_recognition as sr
from gtts import gTTS
from pydub import AudioSegment
from pydub.playback import play
import tempfile
import os

st.write("""
# Urdu Voice Assistant App
## Made by **Feroz Khan**
In this app  users can give a voice input in  اردو  and it should process the input and generate a response in speech in  اردو  language.
         """)

st.header("اپنی آواز اردو میں ریکارڈ کریں")

# Function to record voice input
def record_voice():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        st.info("Recording...")
        audio = recognizer.listen(source)
        st.info("Recording complete.")
        return audio

# Function to convert speech to text
def speech_to_text(audio):
    recognizer = sr.Recognizer()
    try:
        text = recognizer.recognize_google(audio, language="ur-PK")
        return text
    except sr.UnknownValueError:
        return "Sorry, I could not understand the audio."
    except sr.RequestError as e:
        return f"Could not request results; {e}"

# Function to generate a response
def generate_response(input_text):
    response_text = f"آپ نے کہا: {input_text}"
    return response_text

# Function to convert text to speech
def text_to_speech(text):
    tts = gTTS(text=text, lang='ur')
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as fp:
        tts.save(fp.name)
        return fp.name


if st.button("Record"):
    audio = record_voice()
    input_text = speech_to_text(audio)
    st.write(f"Recognized Text: {input_text}")
    
    response_text = generate_response(input_text)
    st.write(f"Response Text: {response_text}")
    
    st.info("Generating speech output...")
    audio_file = text_to_speech(response_text)
    st.audio(audio_file, format="audio/mp3")

    # Cleanup the temporary files
    if os.path.exists(audio_file):
        os.remove(audio_file)
